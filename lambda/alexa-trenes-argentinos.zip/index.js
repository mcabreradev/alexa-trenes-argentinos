// This file re-exports the handler from src/index.js
module.exports = require('./src/index');
