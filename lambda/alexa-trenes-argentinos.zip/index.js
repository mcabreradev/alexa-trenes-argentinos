// This file re-exports the handler from dist/index.js
module.exports = require('./dist/index');
